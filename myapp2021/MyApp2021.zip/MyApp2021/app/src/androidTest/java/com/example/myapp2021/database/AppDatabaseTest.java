package com.example.myapp2021.database;

import junit.framework.TestCase;

public class AppDatabaseTest extends TestCase {

}